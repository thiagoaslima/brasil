import { NgModule } from '@angular/core';
import { PanoramaShellComponent } from './panorama-shell/panorama-shell.component';

@NgModule({
    imports: [
        
    ],
    exports: [],
    declarations: [
        PanoramaShellComponent
    ],
    providers: []
})
export class Panorama2Module { }