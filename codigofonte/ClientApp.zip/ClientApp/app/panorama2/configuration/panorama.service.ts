import { Injectable } from '@angular/core';

import { PANORAMA } from './panorama.configuration';

function sortIndicadoresByTemas({temas, indicadores}) {
    
}

@Injectable()
export class PanoramaService {
    
    constructor() {}


}