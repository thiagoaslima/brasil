export const TEMAS = {
    nenhum: "",
    agricultura: "Agricultura",
    agropecuaria: "Agropecuária",
    comercio: "Comércio",
    educacao: "Educação",
    economia: "Economia",
    frota: "Frota de veículos",
    historico: 'Histórico',
    industria: "Indústria",
    meioAmbiente: "Território e Ambiente",
    populacao: "População",
    saude: "Saúde",
    servicos: "Serviços",
    territorio: "Território",
    trabalho: "Trabalho e Rendimento"
}