import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'visao-historica',
    templateUrl: 'visao-historica.template.html',
	styleUrls: ['visao-historica.style.css']
})

export class VisaoHistoricaComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}