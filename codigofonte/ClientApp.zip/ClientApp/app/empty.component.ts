import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'empty-location.guard.ts',
    template: ``
})

export class EmptyComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}