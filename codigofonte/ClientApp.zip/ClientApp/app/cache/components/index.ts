export { IndicadorCacheComponent } from './indicador-cache.component';
export { PesquisaCacheComponent } from './pesquisa-cache.component';

