export function arrayUniqueValues(array: any[]) {
    return Array.from(new Set(array));
}