export function converterEmNumero(valor: string) {
    return Number.parseInt(valor, 10);
}