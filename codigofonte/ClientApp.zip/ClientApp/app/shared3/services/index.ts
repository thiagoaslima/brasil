export { IndicadorService3 } from './indicador.service';
export { PesquisaService3 } from './pesquisa.service';
export { ResultadoService3 } from './resultado.service';

