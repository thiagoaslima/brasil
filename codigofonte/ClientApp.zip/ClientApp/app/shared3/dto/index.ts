export { LocalDTO } from './local.interface';
export { IndicadorDTO } from './indicador.interface';
export { PesquisaDTO } from './pesquisa.interface';
export { ResultadoDTO } from './resultado.interface';
