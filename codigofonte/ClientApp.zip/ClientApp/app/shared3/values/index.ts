export { escopoIndicadores } from './escopo-indicadores.values'
export { listaNiveisTerritoriais, niveisTerritoriais } from './niveis-territoriais.values'
export { ServicoDados } from './servicoDados.values';
