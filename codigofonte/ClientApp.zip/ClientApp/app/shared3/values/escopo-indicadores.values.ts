export const escopoIndicadores = {
    proprio: 'base',
    filhos: 'one',
    arvoreCompleta: 'sub'
}