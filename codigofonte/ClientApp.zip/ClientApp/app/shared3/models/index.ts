export { Indicador, IndicadorParameters } from './indicador.model'
export { Pesquisa } from './pesquisa.model'
export { Resultado } from './resultado.model';