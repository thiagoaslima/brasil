// https://github.com/topojson/topojson-client Version 2.1.0. Copyright 2016 Mike Bostock.
import { OpaqueToken } from '@angular/core';

interface featureObj {
    type: any;
    geometries?: any;
    coordinates?: any;
}

var identity = function (x, _i?) {
    return x;
};

var transform = function (topology) {
    if ((transform = topology.transform) == null) return identity;
    var transform,
        x0,
        y0,
        kx = transform.scale[0],
        ky = transform.scale[1],
        dx = transform.translate[0],
        dy = transform.translate[1];
    return function (point, i?) {
        if (!i) x0 = y0 = 0;
        point[0] = (x0 += point[0]) * kx + dx;
        point[1] = (y0 += point[1]) * ky + dy;
        return point;
    };
};

var bbox = function (topology) {
    var bbox = topology.bbox;

    function bboxPoint(p0) {
        p1[0] = p0[0], p1[1] = p0[1], t(p1);
        if (p1[0] < x0) x0 = p1[0];
        if (p1[0] > x1) x1 = p1[0];
        if (p1[1] < y0) y0 = p1[1];
        if (p1[1] > y1) y1 = p1[1];
    }

    function bboxGeometry(o) {
        switch (o.type) {
            case "GeometryCollection": o.geometries.forEach(bboxGeometry); break;
            case "Point": bboxPoint(o.coordinates); break;
            case "MultiPoint": o.coordinates.forEach(bboxPoint); break;
        }
    }

    if (!bbox) {
        var t = transform(topology), p0, p1 = new Array(2), name,
            x0 = Infinity, y0 = x0, x1 = -x0, y1 = -x0;

        topology.arcs.forEach(function (arc) {
            var i = -1, n = arc.length;
            while (++i < n) {
                p0 = arc[i], p1[0] = p0[0], p1[1] = p0[1], t(p1, i);
                if (p1[0] < x0) x0 = p1[0];
                if (p1[0] > x1) x1 = p1[0];
                if (p1[1] < y0) y0 = p1[1];
                if (p1[1] > y1) y1 = p1[1];
            }
        });

        for (name in topology.objects) {
            bboxGeometry(topology.objects[name]);
        }

        bbox = topology.bbox = [x0, y0, x1, y1];
    }

    return bbox;
};

var reverse = function (array, n) {
    var t, j = array.length, i = j - n;
    while (i < --j) t = array[i], array[i++] = array[j], array[j] = t;
};

var feature = function (topology, o) {
    return o.type === "GeometryCollection"
        ? { type: "FeatureCollection", features: o.geometries.map(function (o) { return feature$1(topology, o); }) }
        : feature$1(topology, o);
};

function feature$1(topology, o) {
    var id = o.id,
        bbox = o.bbox,
        properties = o.properties == null ? {} : o.properties,
        geometry = object(topology, o);
    return id == null && bbox == null ? { type: "Feature", properties: properties, geometry: geometry }
        : bbox == null ? { type: "Feature", id: id, properties: properties, geometry: geometry }
            : { type: "Feature", id: id, bbox: bbox, properties: properties, geometry: geometry };
}

function object(topology, o) {
    var transformPoint = transform(topology),
        arcs = topology.arcs;

    function arc(i, points) {
        if (points.length) points.pop();
        for (var a = arcs[i < 0 ? ~i : i], k = 0, n = a.length; k < n; ++k) {
            points.push(transformPoint(a[k].slice(), k));
        }
        if (i < 0) reverse(points, n);
    }

    function point(p) {
        return transformPoint(p.slice());
    }

    function line(arcs) {
        var points = [];
        for (var i = 0, n = arcs.length; i < n; ++i) arc(arcs[i], points);
        if (points.length < 2) points.push(points[0].slice());
        return points;
    }

    function ring(arcs) {
        var points = line(arcs);
        while (points.length < 4) points.push(points[0].slice());
        return points;
    }

    function polygon(arcs) {
        return arcs.map(ring);
    }

    function geometry(o): featureObj {
        var type = o.type, coordinates;
        switch (type) {
            case "GeometryCollection": return { type: type, geometries: o.geometries.map(geometry) };
            case "Point": coordinates = point(o.coordinates); break;
            case "MultiPoint": coordinates = o.coordinates.map(point); break;
            case "LineString": coordinates = line(o.arcs); break;
            case "MultiLineString": coordinates = o.arcs.map(line); break;
            case "Polygon": coordinates = polygon(o.arcs); break;
            case "MultiPolygon": coordinates = o.arcs.map(polygon); break;
            default: return null;
        }
        return { type: type, coordinates: coordinates };
    }

    return geometry(o);
}

var stitch = function (topology, arcs) {
    var stitchedArcs = {},
        fragmentByStart = {},
        fragmentByEnd = {},
        fragments = [],
        emptyIndex = -1;

    // Stitch empty arcs first, since they may be subsumed by other arcs.
    arcs.forEach(function (i, j) {
        var arc = topology.arcs[i < 0 ? ~i : i], t;
        if (arc.length < 3 && !arc[1][0] && !arc[1][1]) {
            t = arcs[++emptyIndex], arcs[emptyIndex] = i, arcs[j] = t;
        }
    });

    arcs.forEach(function (i) {
        var e = ends(i),
            start = e[0],
            end = e[1],
            f, g;

        if (f = fragmentByEnd[start]) {
            delete fragmentByEnd[f.end];
            f.push(i);
            f.end = end;
            if (g = fragmentByStart[end]) {
                delete fragmentByStart[g.start];
                var fg = g === f ? f : f.concat(g);
                fragmentByStart[fg.start = f.start] = fragmentByEnd[fg.end = g.end] = fg;
            } else {
                fragmentByStart[f.start] = fragmentByEnd[f.end] = f;
            }
        } else if (f = fragmentByStart[end]) {
            delete fragmentByStart[f.start];
            f.unshift(i);
            f.start = start;
            if (g = fragmentByEnd[start]) {
                delete fragmentByEnd[g.end];
                var gf = g === f ? f : g.concat(f);
                fragmentByStart[gf.start = g.start] = fragmentByEnd[gf.end = f.end] = gf;
            } else {
                fragmentByStart[f.start] = fragmentByEnd[f.end] = f;
            }
        } else {
            f = [i];
            fragmentByStart[f.start = start] = fragmentByEnd[f.end = end] = f;
        }
    });

    function ends(i) {
        var arc = topology.arcs[i < 0 ? ~i : i], p0 = arc[0], p1;
        if (topology.transform) p1 = [0, 0], arc.forEach(function (dp) { p1[0] += dp[0], p1[1] += dp[1]; });
        else p1 = arc[arc.length - 1];
        return i < 0 ? [p1, p0] : [p0, p1];
    }

    function flush(fragmentByEnd, fragmentByStart) {
        for (var k in fragmentByEnd) {
            var f = fragmentByEnd[k];
            delete fragmentByStart[f.start];
            delete f.start;
            delete f.end;
            f.forEach(function (i) { stitchedArcs[i < 0 ? ~i : i] = 1; });
            fragments.push(f);
        }
    }

    flush(fragmentByEnd, fragmentByStart);
    flush(fragmentByStart, fragmentByEnd);
    arcs.forEach(function (i) { if (!stitchedArcs[i < 0 ? ~i : i]) fragments.push([i]); });

    return fragments;
};

var mesh = function (topology) {
    return object(topology, meshArcs.apply(this, arguments));
};

function meshArcs(topology, object$$1, filter) {
    var arcs, i, n;
    if (arguments.length > 1) arcs = extractArcs(topology, object$$1, filter);
    else for (i = 0, arcs = new Array(n = topology.arcs.length); i < n; ++i) arcs[i] = i;
    return { type: "MultiLineString", arcs: stitch(topology, arcs) };
}

function extractArcs(topology, object$$1, filter) {
    var arcs = [],
        geomsByArc = [],
        geom;

    function extract0(i) {
        var j = i < 0 ? ~i : i;
        (geomsByArc[j] || (geomsByArc[j] = [])).push({ i: i, g: geom });
    }

    function extract1(arcs) {
        arcs.forEach(extract0);
    }

    function extract2(arcs) {
        arcs.forEach(extract1);
    }

    function extract3(arcs) {
        arcs.forEach(extract2);
    }

    function geometry(o) {
        switch (geom = o, o.type) {
            case "GeometryCollection": o.geometries.forEach(geometry); break;
            case "LineString": extract1(o.arcs); break;
            case "MultiLineString": case "Polygon": extract2(o.arcs); break;
            case "MultiPolygon": extract3(o.arcs); break;
        }
    }

    geometry(object$$1);

    geomsByArc.forEach(filter == null
        ? function (geoms) { arcs.push(geoms[0].i); }
        : function (geoms) { if (filter(geoms[0].g, geoms[geoms.length - 1].g)) arcs.push(geoms[0].i); });

    return arcs;
}

function planarRingArea(ring) {
    var i = -1, n = ring.length, a, b = ring[n - 1], area = 0;
    while (++i < n) a = b, b = ring[i], area += a[0] * b[1] - a[1] * b[0];
    return Math.abs(area); // Note: doubled area!
}

var merge = function (topology) {
    return object(topology, mergeArcs.apply(this, arguments));
};

function mergeArcs(topology, objects) {
    var polygonsByArc = {},
        polygons = [],
        groups = [];

    objects.forEach(geometry);

    function geometry(o) {
        switch (o.type) {
            case "GeometryCollection": o.geometries.forEach(geometry); break;
            case "Polygon": extract(o.arcs); break;
            case "MultiPolygon": o.arcs.forEach(extract); break;
        }
    }

    function extract(polygon) {
        polygon.forEach(function (ring) {
            ring.forEach(function (arc) {
                (polygonsByArc[arc = arc < 0 ? ~arc : arc] || (polygonsByArc[arc] = [])).push(polygon);
            });
        });
        polygons.push(polygon);
    }

    function area(ring) {
        return planarRingArea(object(topology, { type: "Polygon", arcs: [ring] }).coordinates[0]);
    }

    polygons.forEach(function (polygon) {
        if (!polygon._) {
            var group = [],
                neighbors = [polygon];
            polygon._ = 1;
            groups.push(group);
            while (polygon = neighbors.pop()) {
                group.push(polygon);
                polygon.forEach(function (ring) {
                    ring.forEach(function (arc) {
                        polygonsByArc[arc < 0 ? ~arc : arc].forEach(function (polygon) {
                            if (!polygon._) {
                                polygon._ = 1;
                                neighbors.push(polygon);
                            }
                        });
                    });
                });
            }
        }
    });

    polygons.forEach(function (polygon) {
        delete polygon._;
    });

    return {
        type: "MultiPolygon",
        arcs: groups.map(function (polygons) {
            var arcs = [], n;

            // Extract the exterior (unique) arcs.
            polygons.forEach(function (polygon) {
                polygon.forEach(function (ring) {
                    ring.forEach(function (arc) {
                        if (polygonsByArc[arc < 0 ? ~arc : arc].length < 2) {
                            arcs.push(arc);
                        }
                    });
                });
            });

            // Stitch the arcs into one or more rings.
            arcs = stitch(topology, arcs);

            // If more than one ring is returned,
            // at most one of these rings can be the exterior;
            // choose the one with the greatest absolute area.
            if ((n = arcs.length) > 1) {
                for (var i = 1, k = area(arcs[0]), ki, t; i < n; ++i) {
                    if ((ki = area(arcs[i])) > k) {
                        t = arcs[0], arcs[0] = arcs[i], arcs[i] = t, k = ki;
                    }
                }
            }

            return arcs;
        })
    };
}

var bisect = function (a, x) {
    var lo = 0, hi = a.length;
    while (lo < hi) {
        var mid = lo + hi >>> 1;
        if (a[mid] < x) lo = mid + 1;
        else hi = mid;
    }
    return lo;
};

var neighbors = function (objects) {
    var indexesByArc = {}, // arc index -> array of object indexes
        neighbors = objects.map(function () { return []; });

    function line(arcs, i) {
        arcs.forEach(function (a) {
            if (a < 0) a = ~a;
            var o = indexesByArc[a];
            if (o) o.push(i);
            else indexesByArc[a] = [i];
        });
    }

    function polygon(arcs, i) {
        arcs.forEach(function (arc) { line(arc, i); });
    }

    function geometry(o, i) {
        if (o.type === "GeometryCollection") o.geometries.forEach(function (o) { geometry(o, i); });
        else if (o.type in geometryType) geometryType[o.type](o.arcs, i);
    }

    var geometryType = {
        LineString: line,
        MultiLineString: polygon,
        Polygon: polygon,
        MultiPolygon: function (arcs, i) { arcs.forEach(function (arc) { polygon(arc, i); }); }
    };

    objects.forEach(geometry);

    for (var i in indexesByArc) {
        let _iNumber = parseInt(i, 10);
        for (var indexes = indexesByArc[i], m = indexes.length, j = 0; j < m; ++j) {
            for (var k = j + 1; k < m; ++k) {
                var ij = indexes[j], ik = indexes[k], n;
                if ((n = neighbors[ij])[i = bisect(n, ik).toString()] !== ik.toString()) n.splice(i, 0, ik);
                if ((n = neighbors[ik])[i = bisect(n, ij).toString()] !== ij.toString()) n.splice(i, 0, ij);
            }
        }
    }

    return neighbors;
};

var quantize = function (topology, n) {
    if (!((n = Math.floor(n)) >= 2)) throw new Error("n must be ≥2");
    if (topology.transform) throw new Error("already quantized");
    var bb = bbox(topology), name,
        dx = bb[0], kx = (bb[2] - dx) / (n - 1) || 1,
        dy = bb[1], ky = (bb[3] - dy) / (n - 1) || 1;

    function quantizePoint(p) {
        p[0] = Math.round((p[0] - dx) / kx);
        p[1] = Math.round((p[1] - dy) / ky);
    }

    function quantizeGeometry(o) {
        switch (o.type) {
            case "GeometryCollection": o.geometries.forEach(quantizeGeometry); break;
            case "Point": quantizePoint(o.coordinates); break;
            case "MultiPoint": o.coordinates.forEach(quantizePoint); break;
        }
    }

    topology.arcs.forEach(function (arc) {
        var i = 1,
            j = 1,
            n = arc.length,
            pi = arc[0],
            x0 = pi[0] = Math.round((pi[0] - dx) / kx),
            y0 = pi[1] = Math.round((pi[1] - dy) / ky),
            pj,
            x1,
            y1;

        for (; i < n; ++i) {
            pi = arc[i];
            x1 = Math.round((pi[0] - dx) / kx);
            y1 = Math.round((pi[1] - dy) / ky);
            if (x1 !== x0 || y1 !== y0) {
                pj = arc[j++];
                pj[0] = x1 - x0, x0 = x1;
                pj[1] = y1 - y0, y0 = y1;
            }
        }

        if (j < 2) {
            pj = arc[j++];
            pj[0] = 0;
            pj[1] = 0;
        }

        arc.length = j;
    });

    for (name in topology.objects) {
        quantizeGeometry(topology.objects[name]);
    }

    topology.transform = {
        scale: [kx, ky],
        translate: [dx, dy]
    };

    return topology;
};

var untransform = function (topology) {
    if ((transform = topology.transform) == null) return identity;
    var transform,
        x0,
        y0,
        kx = transform.scale[0],
        ky = transform.scale[1],
        dx = transform.translate[0],
        dy = transform.translate[1];
    return function (point, i) {
        if (!i) x0 = y0 = 0;
        var x1 = Math.round((point[0] - dx) / kx),
            y1 = Math.round((point[1] - dy) / ky);
        point[0] = x1 - x0, x0 = x1;
        point[1] = y1 - y0, y0 = y1;
        return point;
    };
};

export const TopoJson = {
    bbox,
    feature,
    mesh,
    meshArcs,
    merge,
    mergeArcs,
    neighbors,
    quantize,
    transform,
    untransform
};

export let TOPOJSON = new OpaqueToken('TopoJson');