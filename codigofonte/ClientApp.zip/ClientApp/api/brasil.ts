export const brasil = {
    codigo: 0,
    nome: "Brasil",
    slug: "brasil",
    codigoCapital: 5300108
};